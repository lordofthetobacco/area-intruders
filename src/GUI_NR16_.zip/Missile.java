import java.awt.*;

public class Missile extends Rectangle implements GameConstants, Runnable {

    private Thread currentThread;

    Missile(int x, int y) {
        super(x,y, MISSILE_WIDTH, MISSILE_HEIGHT);
        currentThread = new Thread(this);
        currentThread.start();
        THREAD_LIST.add(currentThread);
    }

    public void draw(Graphics g) {
        g.setColor(Color.red);
        g.fillRect(x, y, MISSILE_WIDTH, MISSILE_HEIGHT);
    }

    public void travel() {
        y -= MISSILE_SPEED;
    }

    void checkForDestruction() {
        if (y <= 0) {
            Thread.currentThread().interrupt();
            MISSILES.remove(this);
        }
        for (int i = 0; i < INVADERS.size(); i++) {
            if (INVADERS.get(i).intersects(this)) {
                Thread.currentThread().interrupt();
                INVADERS.get(i).interrupt();
                MISSILES.remove(this);
                INVADERS.remove(INVADERS.get(i));
                Score.addPoint();
            }
        }
    }

    @Override
    public void run() {
        while (true) {
            checkForDestruction();
            travel();
            try {
                Thread.sleep(1000L / 128);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
