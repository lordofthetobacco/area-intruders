import java.awt.*;

public class InvaderMissile extends Rectangle implements GameConstants, Runnable {

    private Thread currentThread;

    InvaderMissile(int x, int y) {
        super(x,y, MISSILE_WIDTH, MISSILE_HEIGHT);
        currentThread = new Thread(this);
        THREAD_LIST.add(currentThread);
    }

    public void draw(Graphics g) {
        g.setColor(Color.yellow);
        g.fillRect(x, y, MISSILE_WIDTH, MISSILE_HEIGHT);
    }

    public void travel() {
        y += MISSILE_SPEED;
    }

    public void interrupt() {
        Thread.currentThread().interrupt();
    }


    @Override
    public void run() {
        while (true) {
            travel();
            try {
                Thread.sleep(1000L / 128);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}
