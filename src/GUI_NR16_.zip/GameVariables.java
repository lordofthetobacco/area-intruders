public class GameVariables {
//    Preferences
    static int CURRENT_BACKGROUND_MODEL_INDEX = 0;
    static boolean FANCY_PLAYER = true;
    static Difficulty DIFFICULTY = Difficulty.MEDIUM;

//    Player Movement
    static int MOVEMENT_AMOUNT = 0;
    static int PLAYER_SPEED = 2;
//    Invader Movement
    static int INVADER_SPEED = 1;
}
