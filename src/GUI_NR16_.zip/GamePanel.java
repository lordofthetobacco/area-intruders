import jdk.jfr.StackTrace;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.html.Option;
import java.awt.*;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;

public class GamePanel extends JPanel implements GameConstants, Runnable{

    Player player;
    Image background;
    Graphics bgGraphics;
    Score score;
    int enemiesRowCount = 5;
    int enemiesCountInRow = SPAWN_COUNT_IN_FIRST_ROW;

    GamePanel() {
        score = new Score();
        add(score.getLabel(), BorderLayout.NORTH);
        setFocusable(true);
        spawnPlayer();
        newEnemies();
        new Thread(this).start();
    }

    private void gameOver() {
        for (Thread thread : THREAD_LIST) {
            try {
                thread.wait();
            } catch (InterruptedException e) {
                new JOptionPane("Game crashed");
            }
        }
    }

    private void spawnPlayer() {
        player = new Player((FRAME_WIDTH / 2 ) - PLAYER_WIDTH,FRAME_HEIGHT - PLAYER_HEIGHT - TOOLBAR_HEIGHT - MENUBAR_HEIGHT, PLAYER_WIDTH, PLAYER_HEIGHT);
    }

    public Player getPlayer() {
        return player;
    }

    public void paint(Graphics g) {
        try {
            background = ImageIO.read(Paths.get("assets", "backgrounds","bg1.jpg").toFile());
        } catch (IOException e) {
            background = createImage(getWidth(), getHeight());
        }
        bgGraphics = background.getGraphics();
        draw(bgGraphics);
        g.drawImage(background,0,0,this);
    }

    public void checkForPlayerCollisions() {
        for (Invader invader : INVADERS) {
            if (player.intersects(invader)) {
                gameOver();
            }
        }
        if (player.x <= 0) {
            player.x = 0;
        }
        if (player.x >= FRAME_WIDTH - PLAYER_WIDTH * 2) {
            player.x = FRAME_WIDTH - PLAYER_WIDTH * 2;
        }
    }

    public void checkForInvaderCollisions() {
        Optional<Invader> furthestInvader = INVADERS.stream().max(Comparator.comparingDouble(Invader::getX));
        Optional<Invader> nearestInvader = INVADERS.stream().min(Comparator.comparingDouble(Invader::getX));
        for (Invader invader : INVADERS) {
            if (furthestInvader.get().x >= FRAME_WIDTH - INVADER_SIZE || nearestInvader.get().x == 1) {
                invader.reverseX();
                invader.y = invader.y + INVADER_SIZE / 2;
            }
        }
    }

    public void newEnemies() {
        int nextPosX;
        int nextPosY = 0;
        for (int i = 0; i < 5; i++) {
            nextPosX = (FRAME_WIDTH / 2) - ((INVADER_SIZE * 2) * SPAWN_COUNT_IN_FIRST_ROW) / 2;
            nextPosY += 2 * INVADER_SIZE;
            for (int j = 0; j < enemiesCountInRow; j++) {
                if (j % 2 == 0) {
                    INVADERS.add(new Invader(nextPosX + INVADER_SIZE/2, nextPosY, INVADER_SIZE, INVADER_SIZE, INVADER_SPEED));
                } else {
                    INVADERS.add(new Invader(nextPosX, nextPosY, INVADER_SIZE, INVADER_SIZE, INVADER_SPEED));
                }
                nextPosX = nextPosX + INVADER_SIZE * 2;
            }
        }
    }


    public void update() {
        checkForPlayerCollisions();
        checkForInvaderCollisions();
        repaint();
    }

    public void draw(Graphics g) {
        player.draw(g);
        for (Invader invader : INVADERS) {
            invader.draw(g);
        }
        for (Missile missile : MISSILES) {
            missile.draw(g);
        }
    }

    @Override
    public void run() {
        while(true) {
            update();
            try{
                Thread.sleep(1000L / 128);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
