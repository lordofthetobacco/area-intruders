import java.awt.*;

public class Player extends Rectangle implements GameConstants, Runnable{

    private Image playerModel = new StreamHandler().loadPlayerModel();
    private Thread currentThread;

    Player(int x, int y, int width, int height) {
        super(x,y,width,height);
        if (playerModel != null) {
            playerModel = playerModel.getScaledInstance(PLAYER_WIDTH, PLAYER_HEIGHT, Image.SCALE_DEFAULT);
        }
        currentThread = new Thread(this);
        THREAD_LIST.add(currentThread);
        currentThread.start();
    }


    public void move() {
        x += GameVariables.MOVEMENT_AMOUNT;
    }

    public void fire() {
        if (MISSILES.isEmpty()) {
            MISSILES.add(new Missile(x + PLAYER_WIDTH / 2 - MISSILE_WIDTH, y + PLAYER_HEIGHT));
        }
    }


    public void draw(Graphics g) {
        if (GameVariables.FANCY_PLAYER && playerModel != null) {
            g.drawImage(playerModel, x,y, null);
        } else {
            g.setColor(Color.GREEN);
            g.fillRect(x,y,height, width);
        }
    }


    @Override
    public void run() {
        while (true) {
                move();
            try{
                Thread.sleep(1000L / 120);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}

