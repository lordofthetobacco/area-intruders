enum Difficulty {
    EASY,
    MEDIUM,
    HARD,
    INSANE
}
