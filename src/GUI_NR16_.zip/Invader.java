import java.awt.*;

public class Invader extends Rectangle implements GameConstants, Runnable {

    private Thread currentThread;
    private boolean shooting;
    private int speed;

    Invader(int x, int y, int width, int height, int speed) {
        super(x,y,width,height);
        this.speed = speed;
        currentThread = new Thread(this);
        THREAD_LIST.add(currentThread);
        currentThread.start();
    }

    public void setSpeed(int newSpeed) {
        speed = newSpeed;
    }

    public void reverseX() {
        speed *= -1;
    }

    public void move() {
        x += speed;
    }


    public void shoot() {
        shooting = true;
        ENEMY_MISSILES.add(new InvaderMissile(x +MISSILE_WIDTH/2-MISSILE_WIDTH, y+GameConstants.MISSILE_WIDTH));
    }

    public void draw(Graphics g) {
        if (shooting) {
            g.setColor(new Color(150,75,0));
        } else {
            g.setColor(Color.ORANGE);
        }
        shooting = false;
        g.fillRect(x,y,width,height);
    }

    public void interrupt() {
        Thread.currentThread().interrupt();
    }
    @Override
    public void run() {
        while (true) {
                move();
            try {
                Thread.sleep(1000L / 128);
            } catch (InterruptedException e) {
                break;
            }
        }
    }
}