import javax.swing.*;

public class Score {

    private static int scoreCounter = 100;

    public static void addPoint() {
        scoreCounter += 10;
    }
    public int getScore() {
        return scoreCounter;
    }
    public void resetScore() {
        scoreCounter = 100;
    }

    public JLabel getLabel() {
        return new JLabel("Current score: " + scoreCounter);
    }
}